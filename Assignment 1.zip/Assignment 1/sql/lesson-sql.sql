CREATE TABLE Pizzaorders (
  fname varchar(255) NOT NULL,
  lname varchar(255) NOT NULL,
  PhoneNumber varchar(255) NOT NULL,
  deliveryAddress varchar(255) NOT NULL,
  PizzaSize varchar(255) NOT NULL,
  Cheese varchar(255) NOT NULL,
  Crust varchar(255) NOT NULL,
  Toppings varchar(255) NOT NULL
);

select * from Pizzaorders;


<!DOCTYPE html>
<html>
<head>
<!--Required Meta Data -->
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Pizza Order Form</title>
	<meta name="description" content="Pizza Form">
	<meta name="robots" content="noindex, nofollow">
    <!--Style Sheet Link -->
    <link rel="stylesheet" href="./css/style.css">
</head>
<body id="form1">
    <!--Header with Heading -->
  <header>
    <h1>Uncle John's</h1>
  </header>
  <main>
    <!--Form Section-->
	<section>
	   <form method="post" class="form">
    <!--First Name Input -->
    <div class="fname">
        <label for="input1">First Name</label>
        <input type="text" name="fname" class="form-control" id="input1">
    </div>
    <br>
    <!--Last Name Input -->
    <div class="lname">
        <label for="input2">Last Name</label>
        <input type="text" name="lname" class="form-control" id="input2">
    </div>
    <br>
    <!--Phone Number Input -->
    <div class="phone">
        <label for="input3">Phone Number</label>
        <input type="text" name="PhoneNumber" class="form-control" id="input3">
    </div>
    <br>
    <!--Address Input -->
    <div class="address">
        <label for="input4">Delivery Address</label>
        <input type="text" name="deliveryAddress" class="form-control" id="input4">
    </div>
    <br>
    <!--Dropdown Menu for Pizza Size using select -->
    <div class="size">
        <p>Pizza Size</p>
        <select name="PizzaSize" class="form-control">
            <option>Select Your Size</option>
            <option value="Small">Small</option>
            <option value="Medium">Medium</option>
            <option value="Large">Large</option>
            <option value="X-Large">X-Large</option>
        </select>
    </div>
    <br>
    <!--Radio Buttons for Cheese Selection -->
    <div class="cheese">
        <p>Cheese</p>
        <input type="radio" name="Cheese" class="form-control" id="cheese1" value="Mozzarella" checked>
        <label for="cheese1">Mozzarella</label><br>
        <input type="radio" name="Cheese" class="form-control" id="cheese2" value="Cheddar">
        <label for="cheese2">Cheddar</label><br>
        <input type="radio" name="Cheese" class="form-control" id="cheese3" value="Parmesan">
        <label for="cheese3">Parmesan</label><br>
        <input type="radio" name="Cheese" class="form-control" id="cheese4" value="Provolone">
        <label for="cheese4">Provolone</label><br>
    </div>
    <br>
    <!--Radio Buttons for Crust selection -->
    <div class="crust">
        <p>Crust</p>
        <input type="radio" name="Crust" class="form-control" id="crust1" value="Thin" checked>
        <label for="crust1">Thin</label><br>
        <input type="radio" name="Crust" class="form-control" id="crust2" value="Thick">
        <label for="crust2">Thick</label><br>
        <input type="radio" name="Crust" class="form-control" id="crust3" value="Stuffed">
        <label for="crust3">Stuffed</label><br>
        <input type="radio" name="Crust" class="form-control" id="crust4" value="Gluten-Free">
        <label for="crust4">Gluten-Free</label><br>
    </div>
    <br>
    <!--Checkbox for selecting the toppings -->
    <div class="toppings">
        <p>Toppings</p>
        <input type="checkbox" name="Toppings[]" class="form-control" id="topping1" value=" Pepperoni ">
        <label for="topping1">Pepperoni</label><br>
        <input type="checkbox" name="Toppings[]" class="form-control" id="topping2" value=" Chicken ">
        <label for="topping2">Chicken</label><br>
        <input type="checkbox" name="Toppings[]" class="form-control" id="topping3" value=" Ham ">
        <label for="topping3">Ham</label><br>
        <input type="checkbox" name="Toppings[]" class="form-control" id="topping4" value=" Pineapple ">
        <label for="topping4">Pineapple</label><br>
        <input type="checkbox" name="Toppings[]" class="form-control" id="topping5" value=" Bell Peppers ">
        <label for="topping5">Bell Peppers</label><br>
        <input type="checkbox" name="Toppings[]" class="form-control" id="topping6" value=" Onions ">
        <label for="topping6">Onions</label><br>
        <input type="checkbox" name="Toppings[]" class="form-control" id="topping7" value=" Tomato ">
        <label for="topping7">Tomato</label><br>
        <input type="checkbox" name="Toppings[]" class="form-control" id="topping8" value=" Olives ">
        <label for="topping8">Olives</label><br>
    </div>
    <br>
    <!--Order Button-->
    <div class="button">
        <input type="submit" value="ORDER">
    </div>
</form>

<a href="view.php">View</a>

<div class="submit-message">
    <!--PHP For Sanitizing the Database entries-->
    <?php
		require_once('database.php');
		if(isset($_POST) & !empty($_POST)){
		$fname = $database->sanitize($_POST['fname']);
		$lname = $database->sanitize($_POST['lname']);
		$PhoneNumber = $database->sanitize($_POST['PhoneNumber']);
		$deliveryAddress = $database->sanitize($_POST['deliveryAddress']);
        $PizzaSize = $database->sanitize($_POST['PizzaSize']);
		$Cheese = $database->sanitize($_POST['Cheese']);
		$Crust = $database->sanitize($_POST['Crust']);
        //Using the following function to take multiple checkbox entries in toppings to store 
        $ToppingsResults = " ";
		$ToppingsName = $_POST['Toppings'];
        foreach($ToppingsName as $ToppingsValue){
            $ToppingsResults .= $ToppingsValue;
        }
		$res   = $database->create($fname, $lname, $PhoneNumber, $deliveryAddress, $PizzaSize, $Cheese, $Crust, $ToppingsResults);
        //Displaying if the Data is being stored to the Database or No
		if($res){
			echo "<p>Successfully inserted data</p>";
		}else{
			echo "<p>Failed to insert data</p>";
		}
		}
		 ?>
        </div>
      </section>
     </main>
   </body>
</html>

<!--END OF CODE-->
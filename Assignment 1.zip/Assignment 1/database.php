<!--This file allows the data to be pushed into the SQL Database after taking inputs from the user using the index.php page-->
<?php
  class Database{
    //Making a Private Connection
    private $connection;
    function __construct(){
      $this->connect_db(); //Establishing a connection to Database 
    }
    //Filling in the Personal Database information to have a successful connection
    public function connect_db(){
      $this->connection = mysqli_connect('172.31.22.43', 'Arnav200542352', 'VDAuZZcf0w', 'Arnav200542352');
      if(mysqli_connect_error()){
        die("Database Connection Failed" . mysqli_connect_error()); //Message shows up if the connection to database is failed
      }
    }
    //Using the variables we used in index.php to define the structure of the table using create and insert function
    public function create($fname,$lname,$PhoneNumber,$deliveryAddress,$PizzaSize, $Cheese, $Crust, $ToppingsResults){
      $sql = "INSERT INTO Pizzaorders(fname, lname, PhoneNumber, deliveryAddress, PizzaSize, Cheese, Crust, ToppingsResults) VALUES ('$fname', '$lname', '$PhoneNumber', '$deliveryAddress', '$PizzaSize', '$Cheese', '$Crust', '$ToppingsResults')";
      $res = mysqli_query($this->connection, $sql);
      if($res){
	 		    return true;
		  }
      else{
			    return false;
		  }
    }
    //Used to make the Data show up in view.php page from the Database Table
    public function read($id=null){
      $sql = "SELECT * FROM Pizzaorders";
      if($id){
        $sql .= " WHERE id=$id";
      }
       $res = mysqli_query($this->connection, $sql);
       return $res;
  }
    public function sanitize($var){
      $return = mysqli_real_escape_string($this->connection, $var);
      return $return;
    }
  }
  $database = new Database();
?>
<!--END OF CODE-->
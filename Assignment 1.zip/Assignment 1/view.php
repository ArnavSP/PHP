<!--This Page is used to display the data stored in the database in a webpage that is linked to index.php-->
<?php
	require_once('database.php');
	$res = $database->read();
?>
<!--Required Meta Data-->
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Pizza Order Form</title>
	<meta name="description" content="Pizza Form">
	<meta name="robots" content="noindex, nofollow">
	<!--Linking the Style Sheet-->
    <link rel="stylesheet" href="./css/style.css">	
</head>
<body>
<div class="container">
	<div class="row">
		<!--Making a table to show the exact input of the user-->
		<table class="table">
			<tr>
				<th>First Name</th>
				<th>Last Name</th>
				<th>Phone Number</th>
				<th>Delivery Address</th>
				<th>Pizza Size</th>
				<th>Cheese</th>
				<th>Crust</th>
				<th>Toppings</th>
			</tr>
			<!--Fetching the data from the Database and displaying it on the table in the view.php page-->
			<?php
				while($r = mysqli_fetch_assoc($res)){
			?>
					<tr>
						<td><?php echo $r['fname']; ?></td>
						<td><?php echo $r['lname']; ?></td>
						<td><?php echo $r['PhoneNumber']; ?></td>
						<td><?php echo $r['deliveryAddress']; ?></td>
						<td><?php echo $r['PizzaSize']; ?></td>
						<td><?php echo $r['Cheese']; ?></td>
						<td><?php echo $r['Crust']; ?></td>
						<td><?php echo $r['ToppingsResults']; ?></td>
					</tr>
				<?php
				}
			?>
		</table>
	</div>
</div>
</body>
</html>
<!--END OF CODE-->

-- Insert sample data into the users table
INSERT INTO users (username, email, password, profile_image)
VALUES ('admin', 'admin@miniblog.com', '$2y$10$hLPggaj00QXJvqQlnI0D3eiJQp9D.TCBXcaJoTRVfqZ4tZM2hNPdi', '../uploads/64d63f0ec4bef_avt823.jpeg'); -- Password: admin123

-- Insert sample data into the content table
INSERT INTO posts (title, content, author_id)
VALUES ('Hello world', 'This is first post.', 1);

-- Add more sample content data as needed

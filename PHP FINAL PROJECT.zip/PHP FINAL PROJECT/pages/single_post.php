<?php
// Script to start session and check if user is logged in or not
include 'scripts/check_login.php';
?>
<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, inital-scale=1">
    <!-- Importing styles -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="styles/style.css">

    <?php
    include 'scripts/db_connect.php';

    // get user role
    $roleSQL = "SELECT role FROM users WHERE id = $user_id";
    $roleSQLResult = mysqli_query($conn, $roleSQL);
    $userRole = '';
    if ($roleSQLResult && mysqli_num_rows($roleSQLResult) > 0) {
        $userInfo = mysqli_fetch_assoc($roleSQLResult);
        $userRole = $userInfo['role'];
    }
    // Check if the post ID is provided in the URL and user is loggedin
    if (isset($_GET['id']) && is_numeric($_GET['id']) && $loggedIn == true) {
        $postId = $_GET['id'];

        // Fetch the post details along with author's name
        $sql = "SELECT posts.*, users.username AS author_name
                    FROM posts
                    INNER JOIN users ON posts.author_id = users.id
                    WHERE posts.id = $postId";

        $result = mysqli_query($conn, $sql);

        //  if post exits, set page title
        if (mysqli_num_rows($result) > 0) {
            $row = mysqli_fetch_assoc($result);
            echo '<title>' . $row['title'] . '</title>';
        } else
            echo '<title>Not found</title>';

    ?>

</head>

<body>
    <!-- adding Header -->
    <?php include 'includes/header.php'; ?>

    <div class="container mt-5">
        <?php

        if (mysqli_num_rows($result) > 0) {
        ?>
            <div class="card">
                <!-- showing post details  -->
                <div class="card-header">
                    <!-- If user id and author id matches, show edit and delete button -->
                    <?php if ($row["author_id"] == $user_id) {
                        echo '<div class="d-flex justify-content-end">';
                        echo '<a class="btn btn-primary mr-4" type="submit" href="?page=edit_post&post_id=' . $row['id'] . '">Edit</a>';
                        echo '<form method="post" action="scripts/delete_post.php"><input type="hidden" name="post_id" value="' . $row["id"] . '"><button class="btn btn-danger" type="submit">Delete</button></form>';
                        echo '</div>';
                    }
                    // if logged in user is admin, show delete btn
                    elseif ($userRole === 'admin') {
                        echo '<div class="d-flex justify-content-end">';
                        echo '<form method="post" action="scripts/delete_post.php"><input type="hidden" name="post_id" value="' . $row["id"] . '"><button class="btn btn-danger" type="submit">Delete</button></form>';
                        echo '</div>';
                    } ?>

                    <!-- title -->
                    <h2 class="card-title"><?php echo htmlspecialchars($row['title']); ?></h2>
                    <!-- author -->
                    <p class="card-subtitle text-muted">posted by <?php echo htmlspecialchars($row['author_name']); ?></p>

                    <!-- update and creation date -->
                    <div class="d-flex justify-content-between flex-column flex-md-row">
                        <small class="card-text ">Created at: <?php echo date("F j, Y - g:i A", strtotime($row["created_at"])); ?></small>
                        <small class="card-text ">Updated at: <?php echo date("F j, Y - g:i A", strtotime($row["updated_at"])); ?></small>
                    </div>
                </div>

                <!-- post content -->
                <div class="card-body">
                    <p class="card-text"><?php echo htmlspecialchars($row['content']); ?></p>
                </div>
            </div>
    <?php
        }

        // if post not found
        else {
            echo '<p>No post found with the provided ID.</p>';
        }
    }

    // if post id is invalid
    else {

        // add header
        include 'includes/header.php';

        //   show error
        echo '<div class="container mt-5">';
        if ($loggedIn == true) echo '<p>Invalid post ID.</p>';
        else echo '<p>You are not logged in.</p>';
        echo '</div>';
    }

    // closing connection

    mysqli_close($conn);
    ?>
    </div>

    <!-- footer -->
    <?php include 'includes/footer.php'; ?>

</body>

</html>
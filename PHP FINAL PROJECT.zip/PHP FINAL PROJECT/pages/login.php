<?php
// Script to start session and check if user is logged in or not
include 'scripts/check_login.php';
if ($loggedIn == true) {
    header('Location: ../');
    exit();
}
?>
<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, inital-scale=1">
    <title>Login</title>

    <!-- Importing styles -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="styles/style.css">
</head>

<body>

    <!-- Header -->
    <?php include 'includes/header.php'; ?>

    <div class="container mt-5">
        <h1 class="main-heading">Login</h1>

        <!-- Form -->
        <form method="post" action="scripts/login_script.php" class="needs-validation" novalidate>
            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" class="form-control" id="username" name="username" required>
                <div class="invalid-feedback">
                    Please provide your username.
                </div>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" class="form-control" id="password" name="password" required>
                <div class="invalid-feedback">
                    Please provide your password.
                </div>
            </div>
            <button type="submit" class="custom-btn custom-btn-primary">Login</button>
        </form>

        <!-- If error occured, show the error -->
        <p><?php if (isset($_SESSION['login_error'])) {
                echo $_SESSION['login_error'];
            }  ?></p>
    </div>

    <?php
    // Footer
    include 'includes/footer.php';

    // Javascript for form validation
    include 'includes/form_script.php';
    ?>
</body>

</html>
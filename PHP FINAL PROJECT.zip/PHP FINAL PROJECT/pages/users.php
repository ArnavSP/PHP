<?php
// Script to start session and check if user is logged in or not
include 'scripts/check_login.php';
?>
<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, inital-scale=1">
    <title>Users</title>

    <!-- importing styles -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="styles/style.css">


</head>

<body>

    <!-- header -->
    <?php include 'includes/header.php'; ?>

    <div class="container mt-5">
        <h1 class="main-heading">Registered Users</h1>
        <?php
        // Connecting with database
        include 'scripts/db_connect.php';

        // checking if user is logged in
        if ($loggedIn == false) {
            echo 'You must be logged in to view users.';
        } else {
            $userId = $user_id;

            // Getting the role of the logged-in user
            $getUserRoleSql = "SELECT role FROM users WHERE id = $userId";
            $getUserRoleResult = mysqli_query($conn, $getUserRoleSql);

            if ($getUserRoleResult && mysqli_num_rows($getUserRoleResult) > 0) {
                $userRole = mysqli_fetch_assoc($getUserRoleResult)['role'];

                // Getting all users
                $getUsersSql = "SELECT * FROM users";
                $getUsersResult = mysqli_query($conn, $getUsersSql);

                // creating table for users
                if ($getUsersResult && mysqli_num_rows($getUsersResult) > 0) {
                    echo '<table class="users-table">';
                    echo '<thead><tr><th>ID</th><th>Username</th><th>Email</th><th>Role</th><th>Image</th><th>Actions</th></tr></thead>';
                    echo '<tbody>';

                    while ($user = mysqli_fetch_assoc($getUsersResult)) {
                        // creating row for each user
                        echo '<tr>';
                        echo '<td>' . $user['id'] . '</td>';
                        echo '<td>' . $user['username'] . '</td>';
                        echo '<td>' . $user['email'] . '</td>';
                        echo '<td>' . $user['role'] . '</td>';

                        echo '<td><img src="' . $user['profile_image'] . '" alt="User Image" width="50"></td>';

                        echo '<td>';

                        // if user id matches logged in id, or logged in user is admin,
                        // then show edit and delete btn
                        if ($userRole === 'admin' || $userId == $user['id']) {
                            echo '<div class="d-flex">';
                            echo '<a href="?page=edit_user&user_id=' . $user['id'] . '" class="btn btn-primary mr-3">Edit</a>';

                            // show delete btn for only rows with role 'user', so admin account can't be deleted
                            if ($user['role'] == 'user')
                                echo '<form method="post" action="scripts/delete_user.php"><input type="hidden" name="user_id" value="' . $user['id'] . '"><button class="btn btn-danger" type="submit">Delete</button></form>';
                            echo '</div>';
                        }

                        echo '</td>';
                        echo '</tr>';
                    }

                    echo '</tbody></table>';
                }
                // if no users were found
                else {
                    echo 'No users found.';
                }
            }
            // if failed to get user role
            else {
                echo 'Unable to determine user role.';
            }
        }


        // closing connection
        mysqli_close($conn);
        ?>

    </div>


    <!-- adding footer -->
    <?php include 'includes/footer.php'; ?>
</body>

</html>
<?php
// Script to start session and check if user is logged in or not
include 'scripts/check_login.php';
if ($loggedIn == true) {
    header('Location: ../');
    exit();
}

?>
<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, inital-scale=1">
    <title>Register</title>

    <!-- importing styles -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="styles/style.css">


</head>

<body>
    <!-- Header -->
    <?php include 'includes/header.php'; ?>

    <div class="container mt-5">

        <!-- Registration form -->
        <h1 class="main-heading">Register</h1>
        <form method="post" action="scripts/register_script.php" enctype="multipart/form-data" class="needs-validation" novalidate>
            <div class="form-group">
                <label for="username">Username:</label>
                <input type="text" class="form-control" id="username" name="username" required>
                <div class="invalid-feedback">
                    Please provide a username.
                </div>
            </div>
            <div class="form-group">
                <label for="email">Email:</label>
                <input type="email" class="form-control" id="email" name="email" required>
                <div class="invalid-feedback">
                    Please provide a valid email address.
                </div>
            </div>
            <div class="form-group">
                <label for="password">Password:</label>
                <input type="password" class="form-control" id="password" name="password" required>
                <div class="invalid-feedback">
                    Please provide a password.
                </div>
            </div>

            <label for="profile_image">Profile Image:</label>

            <div class="custom-file">
                <input type="file" class="custom-file-input" id="profile-image" name="profile_image" required>
                <label class="custom-file-label" for="profile-image">Choose profile image</label>
                <div class="invalid-feedback">Image required</div>
            </div>
            <br /><br />


            <button type="submit" class="custom-btn custom-btn-primary">Register</button>
        </form>


    </div>

    <?php
    // footer
    include 'includes/footer.php';

    // javascript for form validation
    include 'includes/form_script.php';
    ?>

</body>

</html>
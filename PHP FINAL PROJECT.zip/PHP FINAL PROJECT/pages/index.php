<?php
// Script to start session and check if user is logged in or not
include 'scripts/check_login.php';
?>
<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, inital-scale=1">
    <title>Home Page</title>

    <!-- Importing Styles -->
    <link rel="stylesheet" href="styles/style.css">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>

<body>
    <!-- Header -->
    <?php include 'includes/header.php'; ?>

    <div class="container mt-5">
        <div class="jumbotron">
            <p class="main-heading">Welcome to Miniblog</p>

            <p class="lead text-center">Share your thoughts and experiences with the world!</p>


        </div>


        <?php if ($loggedIn == true) : ?>
            <!-- if user is logged in, show this menu -->

            <div class="container text-center my-4">
                <a class="custom-btn custom-btn-primary" href="?page=blog">Blog</a>
                <a class="custom-btn custom-btn-primary" href="?page=new_post">New Post</a>
                <a class="custom-btn custom-btn-primary" href="?page=users">Users</a>

            </div>

        <?php else : ?>
            <!-- if user isn't logged in, show this menu -->

            <div class="container text-center my-4">
                <a class="custom-btn custom-btn-primary" href="?page=login">Login</a>
                <a class="custom-btn custom-btn-primary" href="?page=register">Register</a>

            </div>
        <?php endif; ?>


    </div>

    <!-- Footer -->
    <?php include 'includes/footer.php'; ?>
</body>

</html>
<?php
// Script to start session and check if user is logged in or not
include 'scripts/check_login.php';
?>
<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, inital-scale=1">
    <title>New Post</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="styles/style.css">

</head>

<body>

    <?php include 'includes/header.php' ?>
    <div class="container mt-5">

        <!-- if user is logged in, show post form -->
        <?php if ($loggedIn) : ?>
            <h1 class="main-heading">Add a New Post</h1>
            <form method="post" action="scripts/new_post_script.php" class="needs-validation" novalidate>
                <div class="form-group">

                    <label for="title">Title</label>
                    <input type="text" class="form-control" id="title" name="title" required>
                    <div class="invalid-feedback">
                        Please provide a title.
                    </div>
                </div>
                <div class="form-group">
                    <label for="content">Content</label>
                    <textarea class="form-control" id="content" name="content" rows="6" required></textarea>
                    <div class="invalid-feedback">
                        Please provide content of the post.
                    </div>
                </div>
                <button type="submit" class="custom-btn custom-btn-primary">Add Post</button>

            </form>

            <!-- If error occured, while posting, show the error -->
            <p><?php if (isset($_SESSION['new_post_error'])) echo $_SESSION['new_post_error']; ?></p>

        <?php else : ?>
            <!-- If user isn;t logged in ,show error -->
            <p>You need to be logged in to make a post.</p>
        <?php endif; ?>

    </div>

    <?php

    // footer
    include 'includes/footer.php';

    // javascript for form validation
    include 'includes/form_script.php';
    ?>
</body>

</html>
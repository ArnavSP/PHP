<?php
// Script to start session and check if user is logged in or not
include 'scripts/check_login.php';
?>
<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, inital-scale=1">
    <title>About Us</title>

    <!-- Importing styles -->
    <link rel="stylesheet" href="styles/style.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>

<body>

    <!-- Include header (navbar) -->
    <?php include 'includes/header.php'; ?>


    <!-- Example about us -->
    <div class="container mt-5">
        <div class="jumbotron">
            <h1 class="main-heading">About Us</h1>
            <main>
                <section>
                    <p>Welcome to MiniBlog! Our mission is to provide a platform for users to share their thoughts, ideas, and experiences with others.</p>
                </section>

                <section>
                    <p>MiniBlog was created to encourage meaningful conversations and connections in a simple and user-friendly environment.</p>
                </section>

            </main>

        </div>
    </div>

    <!-- Footer (credits) -->

    <?php include 'includes/footer.php'; ?>
</body>

</html>
<?php
// Script to start session and check if user is logged in or not
include 'scripts/check_login.php';
?>
<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, inital-scale=1">
    <title>Blog Posts</title>

    <!-- Importing styles -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="styles/style.css">

</head>

<body>
    <!-- Adding header navbar -->
    <?php include 'includes/header.php'; ?>
    <div class="container mt-5">

        <h1 class="main-heading">Blog Posts</h1>

        <?php
        // Connecting with database
        include 'scripts/db_connect.php';

        // Fetch all posts from the database if user is logged in
        if ($loggedIn) {
            $sql = "SELECT posts.*, users.username AS author_name FROM posts INNER JOIN users ON posts.author_id = users.id";

            $result = mysqli_query($conn, $sql);

            // if results are returned
            if (mysqli_num_rows($result) > 0) {

                // creating row element which will containing all posts cards
                echo '<div class="row">';

                // runnning loop to get each blog post
                while ($row = mysqli_fetch_assoc($result)) {

                    // Card outer div (for spacing)
                    echo '<div class="p-2 col-12 mb-2 mb-md-0 col-md-6">';
                    echo '<div class="card">';
                    echo '<div class="card-body">';

                    // Post title
                    echo '<h4 class="card-title">' . htmlspecialchars($row['title']) . '</h4>';

                    // Truncating content if it's more than 200 characters
                    $content = htmlspecialchars($row['content']);
                    if (strlen($content) > 200) {
                        $truncatedContent = substr($content, 0, 200) . '...';
                        echo '<p class="card-text">' . $truncatedContent . '</p>';
                    }

                    // if post is less than 200 characters, write as is
                    else {
                        echo '<p class="card-text">' . $content . '</p>';
                    }

                    // Add post link
                    echo '<a href="?page=post&id=' . $row["id"] . '">Read full post</a>';

                    // Formatting date
                    $formattedDate = date("F j, Y - g:i A", strtotime($row["created_at"]));

                    // creating div for author name and posting date
                    echo '<div class="d-flex justify-content-between"><small class="card-text text-secondary">by - ' . $row['author_name'] . '</small><small>' .
                        $formattedDate . '</small></div>';

                    // closing all divs
                    echo '</div>';
                    echo '</div>';
                    echo '</div>';
                }
                echo '</div>';
            }

            // if no posts are available, show this error
            else {
                echo '<p>No posts found.</p>';
            }
        }

        // if user is not logged in, show this text
        else {
            echo 'Login to see blog posts!';
        }


        // close connection
        mysqli_close($conn);
        ?>
    </div>


    <!-- Add footer (credits) -->
    <?php include 'includes/footer.php'; ?>

</body>

</html>
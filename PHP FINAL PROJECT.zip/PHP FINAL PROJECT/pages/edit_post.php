<?php
// Script to start session and check if user is logged in or not
include 'scripts/check_login.php';
?>
<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, inital-scale=1">
    <title>Edit Post</title>

    <!-- Importing styles -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="styles/style.css">

</head>

<body>
    <!-- Adding header (navbar) -->
    <?php include 'includes/header.php' ?>
    <div class="container mt-5">
        <h1 class="main-heading">Edit Post</h1>

        <?php

        // for connection with database
        include 'scripts/db_connect.php';

        // if user is not logged in, show error
        if ($loggedIn == false) {
            echo 'You must be logged in to edit a post.';
        }
        // if user is logged in, then 
        else {

            // get logged in user id
            $userId = $user_id;

            // check if post id is avaiable in url
            $postId = isset($_GET['post_id']) ? $_GET['post_id'] : null;

            // checking  if [post id is valid
            if ($postId && is_numeric($postId)) {


                // getting the post's author ID and the logged-in user's role
                $postInfoSql = "SELECT author_id, role FROM posts INNER JOIN users ON posts.author_id = users.id WHERE posts.id = $postId";
                $postInfoResult = mysqli_query($conn, $postInfoSql);

                if ($postInfoResult && mysqli_num_rows($postInfoResult) > 0) {
                    $postInfo = mysqli_fetch_assoc($postInfoResult);

                    // get author id
                    $authorId = $postInfo['author_id'];
                    $userRole = $postInfo['role'];

                    // only admin and post author will be allowed to edit.

                    // comparing user id and author id if they match
                    if ($userRole === 'admin' || ($userRole === 'user' && $userId == $authorId)) {

                        // User is allowed to edit the post


                        // if request method is post, then handle the request
                        if ($_SERVER['REQUEST_METHOD'] === 'POST') {

                            // Processing the form data and update the post
                            $newTitle = $_POST['new_title'];
                            $newContent = $_POST['new_content'];


                            // sql query
                            $updateSql = "UPDATE posts SET title = '$newTitle', content = '$newContent' WHERE id = $postId";

                            // if query is successfull, post is updated
                            if (mysqli_query($conn, $updateSql)) {

                                // showing success message
                                echo 'Post updated successfully.';

                                // adding post link
                                echo '<br/><a href="?page=post&id=' . $postId . '">Click here to view it</a>';
                            } else {

                                // if something went wrong, show error
                                echo 'Error updating post: ' . mysqli_error($conn);
                            }
                        }

                        // If request method is get, then show edit form
                        else {
                            // Get post data from database
                            $getPostSql = "SELECT * FROM posts WHERE id = $postId";
                            $getPostResult = mysqli_query($conn, $getPostSql);

                            if ($getPostResult && mysqli_num_rows($getPostResult) > 0) {
                                $post = mysqli_fetch_assoc($getPostResult);

                                // Display the edit form amd put values
                                echo '<form method="post" action="" class="needs-validation" novalidate>';
                                echo '<div class="form-group">';
                                echo '<label for="new_title">New Title:</label>';
                                echo '<input type="text" class="form-control" id="new_title" name="new_title" value="' . htmlspecialchars($post['title']) . '" required>';
                                echo '<div class="invalid-feedback">Please provide a title.</div>';
                                echo '</div>';
                                echo '<div class="form-group">';
                                echo '<label for="new_content">New Content:</label>';
                                echo '<textarea class="form-control" id="new_content" name="new_content" rows="5" required>' . htmlspecialchars($post['content']) . '</textarea>';
                                echo '<div class="invalid-feedback">Please provide content.</div>';
                                echo '</div>';
                                echo '<button type="submit" class="custom-btn custom-btn-primary">Update Post</button>';
                                echo '</form>';
                            } else {

                                // if post didn't exists, then show error
                                echo 'Post not found.';
                            }
                        }
                    }
                    // if user id, and author id are not same, show error
                    else {
                        echo 'You are not authorized to edit this post.';
                    }
                }

                // if post not, found show error
                else {
                    echo 'Post not found.';
                }
            }

            // if post id is invalid, show this error
            else {
                echo 'Invalid post ID.';
            }
        }

        // close connection
        mysqli_close($conn);
        ?>
    </div>

    <?php

    // show footer
    include 'includes/footer.php';

    // add script for form validation
    include 'includes/form_script.php';
    ?>
</body>

</html>
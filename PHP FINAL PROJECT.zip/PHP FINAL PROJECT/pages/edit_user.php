<?php
// Script to start session and check if user is logged in or not
include 'scripts/check_login.php';

// Connecting with database
include 'scripts/db_connect.php';
?>
<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, inital-scale=1">
    <title>Edit User</title>

    <!-- Importing styles -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="styles/style.css">

</head>

<body>
    <!-- Adding header (navbar) -->
    <?php include 'includes/header.php' ?>
    <div class="container mt-5">
        <h1 class="main-heading">Edit User</h1>


        <!-- checking if user is logged in or not -->
        <?php
        if ($loggedIn == false) {
            echo 'You must be logged in.';
            exit();
        }

        // checking user id
        $loggedInUserId = $user_id;

        // checking if user if is present in url
        $userId = isset($_GET['user_id']) ? $_GET['user_id'] : null;

        // if user id is not present in url, show error
        if (!$userId) {
            echo 'Invalid user ID.';
            exit();
        }

        // Checking if the logged-in user is an admin or the same user being edited
        $getUserRoleSql = "SELECT role FROM users WHERE id = $loggedInUserId";
        $getUserRoleResult = mysqli_query($conn, $getUserRoleSql);

        if ($getUserRoleResult && mysqli_num_rows($getUserRoleResult) > 0) {
            $userRole = mysqli_fetch_assoc($getUserRoleResult)['role'];

            // if user is not admin or logged in user and requested user id doesnt match
            // show error
            if ($userRole !== 'admin' && $userId != $loggedInUserId) {
                echo 'You are not authorized to edit this user.';
                exit();
            }

            // if request method is post, handle request
            if ($_SERVER['REQUEST_METHOD'] === 'POST') {


                // checking if image is available in request
                if (!empty($_FILES)) {
                    // Process the form data and update the user
                    $newUsername = $_POST['new_username'];
                    $newEmail = $_POST['new_email'];

                    // Creating the upload directory if it doesn't exist
                    $targetDir = "../uploads/";
                    if (!file_exists($targetDir)) {
                        mkdir($targetDir, 0777, true);
                    }

                    // Handling uploaded image
                    $imageName = uniqid() . '_' . basename($_FILES["profile_image"]["name"]);
                    $targetPath = $targetDir . $imageName;
                    $uploadOk = 1;
                    $imageFileType = strtolower(pathinfo($targetPath, PATHINFO_EXTENSION));

                    // Checking if image file is a actual image or fake image
                    if (isset($_POST["submit"])) {
                        $check = getimagesize($_FILES["profile_image"]["tmp_name"]);
                        if ($check !== false) {
                            $uploadOk = 1;
                        } else {
                            $uploadOk = 0;
                        }
                    }

                    // Checking if file already exists
                    if (file_exists($targetPath)) {
                        $uploadOk = 0;
                    }

                    // Checking file size
                    if ($_FILES["profile_image"]["size"] > 500000) {
                        $uploadOk = 0;
                    }

                    // Allowing certain file formats
                    if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
                        $uploadOk = 0;
                    }

                    // Checking if $uploadOk is set to 0 by an error
                    if ($uploadOk == 0) {
                        echo "Sorry, your file was not uploaded.<br/>";
                        $updateSql = "UPDATE users SET username = '$newUsername', email = '$newEmail' WHERE id = $userId";
                    } else {
                        if (move_uploaded_file($_FILES["profile_image"]["tmp_name"], $targetPath)) {
                            $updateSql = "UPDATE users SET username = '$newUsername', email = '$newEmail', profile_image = '$targetPath' WHERE id = $userId";
                        } else {
                            echo "Image not updated<br/>";
                            $updateSql = "UPDATE users SET username = '$newUsername', email = '$newEmail' WHERE id = $userId";
                        }
                    }

                    // update user
                    // update query
                    $updateSql = "UPDATE users SET username = '$newUsername', email = '$newEmail', profile_image = '$targetPath' WHERE id = $userId";


                    // check if user is edited or not
                    if (mysqli_query($conn, $updateSql)) {
                        echo 'User updated successfully.';
                    } else {
                        echo 'Error updating user: ' . mysqli_error($conn);
                    }
                }

                // if image is not available, update user email and username only
                else {


                    $newUsername = $_POST['new_username'];
                    $newEmail = $_POST['new_email'];

                    // update query
                    $updateSql = "UPDATE users SET username = '$newUsername', email = '$newEmail' WHERE id = $userId";

                    // check if user is edited or not
                    if (mysqli_query($conn, $updateSql)) {
                        echo 'User updated successfully.';
                    } else {
                        echo 'Error updating user: ' . mysqli_error($conn);
                    }
                }
            }

            // If request is GET, show edit form
            else {

                // get data from database
                $getUserSql = "SELECT * FROM users WHERE id = $userId";
                $getUserResult = mysqli_query($conn, $getUserSql);

                // if data is available, show edit form and input data
                if ($getUserResult && mysqli_num_rows($getUserResult) > 0) {
                    $user = mysqli_fetch_assoc($getUserResult);

                    echo '<form method="post" action="" enctype="multipart/form-data" class="needs-validation" novalidate>';
                    echo '<div class="form-group">';
                    echo '<label for="new_username">New Username:</label>';
                    echo '<input type="text" class="form-control" id="new_username" name="new_username" value="' . htmlspecialchars($user['username']) . '" required>';
                    echo '<div class="invalid-feedback">Please provide a username.</div>';
                    echo '</div>';
                    echo '<div class="form-group">';
                    echo '<label for="new_email">New Email:</label>';
                    echo '<input type="email" class="form-control" id="new_email" name="new_email" value="' . htmlspecialchars($user['email']) . '" required>';
                    echo '<div class="invalid-feedback">Please provide a valid email address.</div>';
                    echo '</div>';
                    echo '<label for="profile_image">Profile Image:</label>

                        <div class="custom-file">
                            <input type="file" class="custom-file-input" id="profile_image" name="profile_image">
                            <label class="custom-file-label" for="profile_image">Choose profile image</label>
                        </div>';
                    echo '<button type="submit" class="custom-btn custom-btn-primary">Update User</button>';
                    echo '</form>';
                }

                // if user doesn't exists, show error
                else {
                    echo 'User not found.';
                }
            }
        }

        // if failed to get user role, show error
        else {
            echo 'Unable to determine user role.';
        }

        // closing connection
        mysqli_close($conn);
        ?>

    </div>

    <?php
    // footer
    include 'includes/footer.php';


    // javascript for form validation
    include 'includes/form_script.php';
    ?>
</body>

</html>
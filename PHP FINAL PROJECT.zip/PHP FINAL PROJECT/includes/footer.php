<footer class="footer">
    <div class="container text-center mt-5">
        <p>&copy; <?php echo date("Y"); ?> MiniBlog. All rights reserved.</p>
    </div>
</footer>
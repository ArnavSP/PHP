<?php
// Starting the session if it's not already active
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
$loggedIn = false;
if (isset($_SESSION["loggedIn"])) {
    $loggedIn = $_SESSION["loggedIn"];
}
$page = "";
if (isset($_GET['page'])) {
    $page = $_GET['page'];
}
?>
<header>

    <!-- Nav bar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="container">
            <!-- Logo -->
            <span class="navbar-brand">MiniBlog</span>

            <!-- Menu -->
            <ul class="navbar-nav ml-auto">

                <div class="d-flex">
                    <div>
                        <a class="nav-link mr-4<?php if ($page == 'about')
                                                    echo ' active';
                                                ?>" href="?page=about">About</a>
                    </div>

                    <!-- Showing menu based on if user is logged in or not -->
                    <?php if ($loggedIn) : ?>

                        <!-- User is logged, show blog, post etc -->
                        <div>
                            <a class="nav-link mr-4<?php if ($page == 'blog')
                                                        echo ' active';
                                                    ?>" href="?page=blog">Blog</a>
                        </div>
                        <div>
                            <a class="nav-link mr-4<?php if ($page == 'new_post')
                                                        echo ' active';
                                                    ?>" href="?page=new_post">New Post</a>
                        </div>
                        <div>
                            <a class="nav-link mr-4<?php if ($page == 'users')
                                                        echo ' active';
                                                    ?>" href="?page=users">Users</a>
                        </div>
                        <div>
                            <a class="nav-link" href="scripts/logout.php">Logout</a>
                        </div>

                    <?php else : ?>

                        <!-- User is not logged in, so show login and register menu -->
                        <div>
                            <a class="nav-link mr-4<?php if ($page == 'register')
                                                        echo ' active';
                                                    ?>" href="?page=register">Register</a>
                        </div>
                        <div>
                            <a class="nav-link mr-4 <?php if ($page == 'login')
                                                        echo ' active';
                                                    ?>" href="?page=login">Login</a>
                        </div>
                    <?php endif; ?>
                </div>
            </ul>
        </div>
    </nav>
</header>
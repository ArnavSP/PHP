<?php

// Checking the requested page
// If it doesn't exists, set it to home
$page = isset($_GET['page']) ? $_GET['page'] : 'home';

// Array of valid pages
$validPages = array('home', 'about', 'blog', 'post', 'register', 'new_post', 'users', 'login', 'edit_post', 'edit_user');

// Checking if the requested page is valid
if (!in_array($page, $validPages)) {
    // Settig default to home page if the requested page is invalid
    $page = 'home';
}


// Adding page according to requested page
switch ($page) {
    case 'home':
        include 'pages/index.php';
        break;
    case 'about':
        include 'pages/about.php';
        break;
    case 'register':
        include 'pages/register.php';
        break;
    case 'post':
        include 'pages/single_post.php';
        break;
    case 'new_post':
        include 'pages/new_post.php';
        break;
    case 'blog':
        include 'pages/blog_posts.php';
        break;
    case 'users':
        include 'pages/users.php';
        break;
    case 'login':
        include 'pages/login.php';
        break;
    case 'edit_post':
        include 'pages/edit_post.php';
        break;
        break;
    case 'edit_user':
        include 'pages/edit_user.php';
        break;
    default:
        include 'pages/index.php'; // Default to home page
        break;
}

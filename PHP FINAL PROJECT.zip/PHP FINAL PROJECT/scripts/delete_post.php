<?php
include 'check_login.php';
include 'db_connect.php';

// checking if user is logged in
if ($loggedIn == false) {
    echo 'You must be logged in to delete a post.';
} else {
    $userId = $user_id;

    // checking for post id in url
    $postId = isset($_POST['post_id']) ? $_POST['post_id'] : null;

    // checking user role
    $roleSQL = "SELECT role FROM users WHERE id = $user_id";
    $roleSQLResult = mysqli_query($conn, $roleSQL);
    $loggedInUserRole = '';
    if ($roleSQLResult && mysqli_num_rows($roleSQLResult) > 0) {
        $userInfo = mysqli_fetch_assoc($roleSQLResult);
        $loggedInUserRole = $userInfo['role'];
    }

    // checing post id
    if ($postId && is_numeric($postId)) {
        // Get the post's author ID and the logged-in user's role
        $postInfoSql = "SELECT posts.author_id, users.role FROM posts INNER JOIN users ON posts.author_id = users.id WHERE posts.id = $postId";
        $postInfoResult = mysqli_query($conn, $postInfoSql);

        if ($postInfoResult && mysqli_num_rows($postInfoResult) > 0) {
            $postInfo = mysqli_fetch_assoc($postInfoResult);
            $authorId = $postInfo['author_id'];
            $userRole = $postInfo['role'];

            // if user logged in is admin or if author and user id matches
            if ($loggedInUserRole === 'admin' || ($loggedInUserRole === 'user' && $userId == $authorId)) {
                // User is allowed to delete the post
                $deleteSql = "DELETE FROM posts WHERE id = $postId";

                // checking if query is successful
                if (mysqli_query($conn, $deleteSql)) {
                    header("Location: ?page=blog");
                } else {
                    echo 'Error deleting post: ' . mysqli_error($conn);
                }
            } else {
                echo 'You are not authorized to delete this post.';
            }
        }

        // if post not found
        else {
            echo 'Post not found.';
        }
    } else {
        echo 'Invalid post ID.';
    }
}
// closing connection
mysqli_close($conn);

<?php
session_start();
include 'db_connect.php';

// checking if user is logged in

if ($_SESSION['loggedIn'] == false) {
    echo 'You must be logged in to delete a post.';
} else {

    // getting user id
    $loggedInUserId = $_SESSION['user_id'];
    $userId = isset($_POST['user_id']) ? $_POST['user_id'] : null;
    // Checking if the logged-in user is an admin or the same user being deleted
    $getUserRoleSql = "SELECT role FROM users WHERE id = $loggedInUserId";
    $getUserRoleResult = mysqli_query($conn, $getUserRoleSql);

    if ($getUserRoleResult && mysqli_num_rows($getUserRoleResult) > 0) {
        $userRole = mysqli_fetch_assoc($getUserRoleResult)['role'];

        if ($userRole === 'admin' || $userId == $loggedInUserId) {
            // Delete the user
            $deleteUserSql = "DELETE FROM users WHERE id = $userId";
            if (mysqli_query($conn, $deleteUserSql)) {
                if ($userId == $loggedInUserId) {
                    // Clearing all session variables
                    $_SESSION = array();

                    // Destroying the session
                    session_destroy();

                    // Redirecting to the home page
                    header("Location: ../");
                    exit();
                } else {
                    header("Location: ../?page=users");
                    exit();
                }
            } else {
                echo 'Error deleting user: ' . mysqli_error($conn);
            }
        }

        // if user is not admin, or user logged and user being deleted ids doesnt match
        else {
            echo 'You are not authorized to delete this user.';
        }
    }

    // if failed to get user role
    else {
        echo 'Unable to determine user role.';
    }
}

// closing connection
mysqli_close($conn);

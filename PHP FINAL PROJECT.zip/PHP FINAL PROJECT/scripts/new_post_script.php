<?php
include 'check_login.php';
include 'db_connect.php';

// Check if the user is logged in or not
if ($loggedIn == false) {
    echo '<p>You must be logged in to add a post.</p>';
} else {

    // if request method is post
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {

        // get values from request
        $userId = $_SESSION['user_id'];
        $title = $_POST['title'];
        $content = $_POST['content'];

        $title = mysqli_real_escape_string($conn, $title);
        $content = mysqli_real_escape_string($conn, $content);

        // Inserting the new post into the database
        $sql = "INSERT INTO posts (title, content, author_id)
                        VALUES ('$title', '$content', $userId)";

        // if successfull
        if (mysqli_query($conn, $sql)) {
            $newPostId = mysqli_insert_id($conn); // Get the ID of the newly created post
            $_SESSION['new_post_error'] = '';
            header("Location: ../?page=post&id=" . $newPostId); // Redirect to home page

        }
        // if error occurred
        else {
            $_SESSION['new_post_error'] = 'Error adding post: ' . mysqli_error($conn);
            header("Location: ?page=new_post");
            exit();
        }
    }
}

// closing connection
mysqli_close($conn);

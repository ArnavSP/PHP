<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start(); // Start the session if it's not already active
}

// set it to false initially
$loggedIn = false;
$user_id = "";

// checking logged in in session
if (isset($_SESSION['loggedIn']) && $_SESSION['loggedIn'] === true) {
    $loggedIn = true;

    // checking user id in session
    if (isset($_SESSION['user_id'])) {
        $user_id = $_SESSION['user_id'];
    }
}

<?php
session_start();
// connecting with db
include 'db_connect.php';

ob_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST["username"];
    $email = $_POST["email"];
    $password = password_hash($_POST["password"], PASSWORD_BCRYPT);

    // Checking for duplicate username
    $checkUsernameQuery = "SELECT id FROM users WHERE username='$username'";
    $checkUsernameResult = mysqli_query($conn, $checkUsernameQuery);
    if (mysqli_num_rows($checkUsernameResult) > 0) {
        echo "Username already exists.";
        exit;
    }

    // Checking for duplicate email
    $checkEmailQuery = "SELECT id FROM users WHERE email='$email'";
    $checkEmailResult = mysqli_query($conn, $checkEmailQuery);
    if (mysqli_num_rows($checkEmailResult) > 0) {
        echo "Email already exists.";
        exit;
    }

    // Creating the upload directory if it doesn't exist
    $targetDir = "../uploads/";
    if (!file_exists($targetDir)) {
        mkdir($targetDir, 0777, true);
    }

    // Handling uploaded image
    $imageName = uniqid() . '_' . basename($_FILES["profile_image"]["name"]);
    $targetPath = $targetDir . $imageName;
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($targetPath, PATHINFO_EXTENSION));

    // Checking if image file is a actual image or fake image
    if (isset($_POST["submit"])) {
        $check = getimagesize($_FILES["profile_image"]["tmp_name"]);
        if ($check !== false) {
            $uploadOk = 1;
        } else {
            echo "File is not an image.";

            $uploadOk = 0;
        }
    }

    // Checking if file already exists
    if (file_exists($targetPath)) {
        echo "Sorry, file already exists.";
        $uploadOk = 0;
    }

    // Checking file size
    if ($_FILES["profile_image"]["size"] > 500000) {
        echo "Sorry, your file is too large.";
        $uploadOk = 0;
    }

    // Allowing certain file formats
    if ($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg" && $imageFileType != "gif") {
        echo "Only images are allowed.";
        $uploadOk = 0;
    }

    // Checking if $uploadOk is set to 0 by an error
    if ($uploadOk == 0) {
        echo "Sorry, your file was not uploaded.";
    } else {
        if (move_uploaded_file($_FILES["profile_image"]["tmp_name"], $targetPath)) {
        } else {
            echo "Sorry, there was an error uploading your file.";
        }
    }

    // Inserting user data into database
    $sql = "INSERT INTO users (username, email, password, profile_image) VALUES ('$username', '$email', '$password', '$targetPath')";
    if (mysqli_query($conn, $sql)) {
        $newUserId = mysqli_insert_id($conn); // Get the ID of the newly inserted user

        $_SESSION['loggedIn'] = true;
        // Saving the new user ID in the session
        $_SESSION["user_id"] = $newUserId;

        ob_end_clean(); // Discard the buffered output
        header("Location: ../");
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        exit;
    }

    ob_end_flush();

    //closing connection
    mysqli_close($conn);
}

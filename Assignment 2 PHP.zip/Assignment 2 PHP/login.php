<?php
session_start();  // Starting a new or resume an existing session
require_once 'db_config.php';  // Including the database configuration file

$error_message = "";  // Initialize an empty error message

// Checking if the form was submitted for sign-up or sign-in
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $action = $_POST["action"];  // Getting the action from the submitted form
    $username = $_POST["username"];  // Getting the submitted username
    $password = $_POST["password"];  // Getting the submitted password

    if ($action === "signup") {
        // Handle user sign-up
        if (!empty($username) && !empty($password)) {
            // Performing further input validation if needed

            // Hashing the password securely
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

            // Inserting user into the database using prepared statements
            $sql = "INSERT INTO users (username, password) VALUES (?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ss", $username, $hashedPassword);

            if ($stmt->execute()) {
                $error_message = "Sign-up successful! You can now log in.";  // Displaying success message
            } else {
                $error_message = "Error signing up. Please try again.";  // Displaying error message
            }
        } else {
            $error_message = "Username and password are required.";  // Displaying error message if fields are empty
        }
    } else {
        // Handle user sign-in
        $sql = "SELECT * FROM users WHERE username = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $username);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows === 1) {
            $row = $result->fetch_assoc();
            // Verifying the provided password with the stored hashed password
            if (password_verify($password, $row['password'])) {
                // Seting session variables and redirect to login-success.php
                $_SESSION["username"] = $username;
                header("Location: login-success.php");
                exit();
            } else {
                $error_message = "Invalid username or password. Please try again.";
            }
        } else {
            $error_message = "Invalid username or password. Please try again.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="styles.css">
    <title>Login</title>
</head>
<body>
    <h2>Sign Up</h2>
    <form id="sign-up-form" action="login.php" method="post">
        <input type="hidden" name="action" value="signup">
        <label for="new_username">Username:</label>
        <input type="text" id="new_username" name="username" required>
        <label for="new_password">Password:</label>
        <input type="password" id="new_password" name="password" required>
        <button type="submit">Register</button>
    </form>
    <h2>Sign In</h2>
    <form id="sign-in-form" action="login.php" method="post">
        <input type="hidden" name="action" value="signin">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" required>
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required>
        <button type="submit">Log In</button>
        <?php if (!empty($error_message)) { ?>
            <p class="error"><?php echo $error_message; ?></p>
        <?php } ?>
    </form>
</body>
</html>

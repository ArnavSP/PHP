<?php
session_start();  // Starting or resume a session

// Destroying the session and its data
session_destroy();

// Redirecting to the login page
header("Location: login.php");

// Terminates the script
exit();
?>

<?php
require_once 'db_config.php';

// Sample user data
$userData = array(
    'username' => 'testuser',
    'password' => 'testpassword'
);

// Hash the password securely
$hashedPassword = password_hash($userData['password'], PASSWORD_DEFAULT);

// Prepare the SQL query using parameterized statements
$sql = "INSERT INTO users (username, password) VALUES (?, ?)";
$stmt = $conn->prepare($sql);

if ($stmt) {
    // Bind parameters and execute the statement
    $stmt->bind_param("ss", $userData['username'], $hashedPassword);
    if ($stmt->execute()) {
        echo "New user inserted!";
    } else {
        echo "Error inserting user: " . $stmt->error;
    }
    $stmt->close();
} else {
    echo "Statement preparation error: " . $conn->error;
}

$conn->close();
?>


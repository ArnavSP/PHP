<?php
// Including the database configuration file
require_once 'db_config.php';

// Sample user data
$userData = array(
    'username' => 'testuser',        // Sample username
    'password' => 'testpassword'     // Sample password
);

// Hashing the password securely using the default hashing algorithm
$hashedPassword = password_hash($userData['password'], PASSWORD_DEFAULT);

// Preparing the SQL query using parameterized statements
$sql = "INSERT INTO users (username, password) VALUES (?, ?)";  // SQL query template
$stmt = $conn->prepare($sql);  // Prepare the statement

if ($stmt) {
    // Binding parameters and executing the statement
    $stmt->bind_param("ss", $userData['username'], $hashedPassword);  // Binding values to placeholders
    if ($stmt->execute()) {
        echo "New user inserted!";  // Displaying success message
    } else {
        echo "Error inserting user: " . $stmt->error;  // Displaying error message if execution fails
    }
    $stmt->close();  // Closing the prepared statement
} else {
    echo "Statement preparation error: " . $conn->error;  // Displaying error message if statement preparation fails
}

$conn->close();  // Closing the database connection
?>

<?php
// Database connection details
$servername = "172.31.22.43";  
$username = "Arnav200542352";  
$password = "VDAuZZcf0w";      
$dbname = "Arnav200542352";    

// Create a new connection using mysqli
$conn = new mysqli($servername, $username, $password, $dbname);

// Check if the connection was successful
if ($conn) {
    echo "Database successfully connected!";  // Display a success message
} elseif ($conn->connect_error) {
    die("Connection was failed: " . $conn->connect_error);  // If connection failed, displaying an error message and terminating the script
}
?>


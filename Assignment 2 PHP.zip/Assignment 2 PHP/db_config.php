<?php
$servername = "172.31.22.43"; 
$username = "Arnav200542352";
$password = "VDAuZZcf0w";
$dbname = "Arnav200542352";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if($conn) {
    echo "Database successfully connected!";
} elseif ($conn->connect_error) {
    die("Connection was failed: " . $conn->connect_error);
}
?>

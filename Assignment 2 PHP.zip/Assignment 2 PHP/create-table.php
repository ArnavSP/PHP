<?php
// Including the database configuration file
require_once 'db_config.php';

// SQL query to create the user table
$sql = "CREATE TABLE users (
    id INT(6) UNSIGNED AUTO_INCREMENT PRIMARY KEY,  -- Create an auto-increment primary key column
    username VARCHAR(50) NOT NULL,  -- Create a column for storing usernames (cannot be empty)
    password VARCHAR(255) NOT NULL   -- Create a column for storing passwords (cannot be empty)
)";

// Check if the query executed successfully
if ($conn->query($sql) === TRUE) {
    echo "Table users created successfully";  // Display a success message
} else {
    echo "Error creating table: " . $conn->error;  // Display an error message if the query failed
}

// Close the database connection
$conn->close();
?>

